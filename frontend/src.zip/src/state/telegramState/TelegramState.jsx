import { makeAutoObservable } from "mobx";

class telegramState {

    constructor() {
        makeAutoObservable(this);
    }

}

export default telegramState;