import React, { useState, useEffect } from "react";
import { Alert, Button } from "@material-tailwind/react";
import { observer } from "mobx-react";
import AppState from "../../state/appState/AppState.js";

const SmallAlert =() => {
    const [visible, setVisible] = useState(false);
    const [message, setMessage] = useState('');

    useEffect(() => {
        // Когда меняется smallAlertMessage, устанавливаем новый текст и делаем уведомление видимым
        if (AppState.smallAlertMessage) {
            setMessage(AppState.smallAlertMessage);
            setVisible(true);
            // Затем через 2 секунды делаем уведомление невидимым
            setTimeout(() => {
                setVisible(false);
            }, 2000);
        }
    }, [AppState.smallAlertMessage]); // Обновляем эффект только при изменении AppState.smallAlertMessage

    return (
        <>
            <div className={'flex justify-center'}>
                <Alert
                    className={'absolute bottom-8 w-96'}
                    open={visible}
                    onClose={() => setVisible(false)}
                    animate={{
                        mount: { y: 0 },
                        unmount: { y: 100 },
                    }}
                >
                    {message}
                </Alert>
            </div>
        </>
    );
};

export default SmallAlert;
