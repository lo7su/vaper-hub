import React from 'react';
import {Typography, Button, Card, CardFooter, CardHeader, CardBody} from "@material-tailwind/react";
import CartItem from "../../cartItem/CartItem.jsx";
import {observer} from "mobx-react";
import {Link} from "react-router-dom";

const CartPage = observer(({cartItems}) => {
    const itemsArray = Object.values(cartItems);
    const totalCost = itemsArray.reduce((sum, item) => sum + item.price, 0);

    return (
        <div className="p-4 bg-pastel-color min-h-[720px]">
            {itemsArray.length > 0 && (
            <Typography variant="h4" className="mb-4 ml-3 text-gray-800 font-light tracking-widest flex justify-center">
                Ваша корзина
            </Typography>
            )}

            <div className={'w-92 flex flex-col justify-center items-center'}>
                {itemsArray.length > 0 && itemsArray.map(item => (
                    <CartItem
                        key={item.id}
                        product={item}
                    />
                ))}
            </div>

            {itemsArray.length === 0 && (
                <div className={'min-h-[620px]  flex items-center justify-center'}>
                    <Card className={''}>
                        <CardBody className={'pb-0'}>
                            <div className={'flex flex-row justify-center items-center'}>
                                <div className={''}>
                                    <Typography variant="h6" className="text-gray-800 font-light tracking-widest">
                                        Ваша корзина корзина пуста.
                                    </Typography>
                                </div>
                            </div>
                        </CardBody>
                        <CardFooter>
                            <div className={'flex justify-center'}>
                                <Link to={'/catalog'}>
                                    <Button variant="gradient" className="text-white font-light ">
                                        Продолжить покупки
                                    </Button>
                                </Link>
                            </div>
                        </CardFooter>
                    </Card>
                </div>
            )}

            {itemsArray.length > 0 && (
                <div>

                </div>
            )}
        </div>
    );
});

export default CartPage;
